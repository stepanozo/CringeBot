﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Telegram.Bot;
using Telegram.Bot.Types;
using Telegram.Bot.Exceptions;
//using Telegram.Bot.Exceptions.Polling;
using Telegram.Bot.Types.ReplyMarkups;
using Telegram.Bot.Types.InputFiles;



namespace Бот_1
{


    internal class Program
    {

        static void Main(string[] args)
        {


            var client = new TelegramBotClient("6019171965:AAELlnnmqAqz0vu2RnxneFsFX3Syxu-n0zU");
            client.StartReceiving(Update, Error); //этих двух методов нет
            Console.ReadLine();
        }

        //Асинхронный метод чтобы чёта в потоках?
        async static Task Update(ITelegramBotClient botClient, Update update, CancellationToken token)
        {
            //это контент, который мы получаем
            var message = update.Message;


            if (message.Text != null)
            {

                //  Console.WriteLine($"{message.Chat.FirstName} | {message.Text}");

                if (!Variables.usersDict.ContainsKey(message.Chat.Id)) //Есть такой юзер или нет
                {
                    Variables.usersDict[message.Chat.Id] = new User();
                    Console.WriteLine($"{message.Chat.FirstName} - зарегистрирован новый пользователь");
                    Console.WriteLine($"{message.Chat.FirstName} with id {message.Chat.Id} started the bot");
                    await botClient.SendTextMessageAsync(message.Chat.Id, text: "Я пробудился. Мои команды:\n\nРеплики\nФото\nПомощь\nИгра\nСтоп", replyMarkup: Variables.DefaultKeyboard);
                    return;
                }
                else if (message.Text == "/start")
                {
                    Console.WriteLine($"{message.Chat.FirstName} with id {message.Chat.Id} started the bot");
                    await botClient.SendTextMessageAsync(message.Chat.Id, "Я пробудился. Мои команды:\n\nРеплики\nФото\nПомощь\nИгра\nСтоп", replyMarkup: Variables.DefaultKeyboard);
                    return;
                }
                else
                {
                    
                    if (message.Text == "Помощь" || message.Text == "/command3")
                    {
                        await botClient.SendTextMessageAsync(message.Chat.Id, "Мои команды:\n\nРеплики\nФото\nПомощь\nИгра\nСтоп");

                        if (Variables.usersDict[message.Chat.Id].gameLevel > 0)
                        {
                            Variables.usersDict[message.Chat.Id].continueGameQuestion = true;
                            await botClient.SendTextMessageAsync(message.Chat.Id, "Продолжить игру?", replyMarkup: Variables.YesOrNoKeyboard);
                        }
                        if (Variables.usersDict[message.Chat.Id].phraseRequest)
                        {
                            Variables.usersDict[message.Chat.Id].continueReplicsQuestion = true;
                            await botClient.SendTextMessageAsync(message.Chat.Id, "Вы хотите дальше запрашивать реплики?", replyMarkup: Variables.YesOrNoKeyboard);
                        }
                        return;
                    }

                    if (message.Text.ToLower().Contains("здорова"))
                    {
                        await botClient.SendTextMessageAsync(message.Chat.Id, "Здоровей видали");
                        return;
                    }

                    if (message.Text == "фото" || message.Text == "Фото" || message.Text == "/command2")
                    {
                        await botClient.SendPhotoAsync(message.Chat.Id, "https://sun1-16.userapi.com/impg/oA0Q-wwYLTWcmhgz28RLe9cT80lH86hsqa61LQ/6XeG19s9NTo.jpg?size=1920x1080&quality=95&sign=5a51378b69731b17edc1044cd189aaf1&type=album", caption: "Именно так выглядит создатель кампаний");
                        if (Variables.usersDict[message.Chat.Id].gameLevel > 0)
                        {
                            Variables.usersDict[message.Chat.Id].continueGameQuestion = true;
                            await botClient.SendTextMessageAsync(message.Chat.Id, "Продолжить игру?", replyMarkup: Variables.YesOrNoKeyboard);
                        }
                        if (Variables.usersDict[message.Chat.Id].phraseRequest)
                            await botClient.SendTextMessageAsync(message.Chat.Id, "Реплики всё ещё активны. Отправьте стоп, если больше не хотите получать реплики или введите имя персонажа.", replyMarkup: Variables.GameAndReplicsKeyboard);
                        return;
                    }




                    if (((message.Text == "/phrases" || message.Text == "Реплики" || message.Text == "реплики" || message.Text == "/command1" || (Variables.usersDict[message.Chat.Id].stopGameForReplicsQuestion && (message.Text == "Да" || message.Text == "да"))))) //меняем переменную для пользователя, найденного по ID
                    {
                        if (Variables.usersDict[message.Chat.Id].gameLevel > 0 && (message.Text == "да" || message.Text == "Да") && Variables.usersDict[message.Chat.Id].stopGameForReplicsQuestion)
                        {
                            Variables.usersDict[message.Chat.Id].stopGameForReplicsQuestion = false;
                            Variables.usersDict[message.Chat.Id].gameLevel = 0;
                        }


                        if (Variables.usersDict[message.Chat.Id].phraseRequest)
                            await botClient.SendTextMessageAsync(message.Chat.Id, "Реплики и так уже активны. Вводите имя персонажа.");


                        if (Variables.usersDict[message.Chat.Id].gameLevel > 0 && !Variables.usersDict[message.Chat.Id].stopGameForReplicsQuestion)
                        {
                            await botClient.SendTextMessageAsync(message.Chat.Id, "Вы хотите прервать игру ради реплик?", replyMarkup: Variables.YesOrNoKeyboard);
                            Variables.usersDict[message.Chat.Id].stopGameForReplicsQuestion = true;
                            return;
                        }



                        await botClient.SendTextMessageAsync(message.Chat.Id, "Реплика какого персонажа тебе нужна? Напиши имя с большой буквы в именительном падеже. Если надоели фразочки героев, напиши стоп", replyMarkup: Variables.GameAndReplicsKeyboard);
                        Variables.usersDict[message.Chat.Id].phraseRequest = true;
                        return;
                    }

                    if (Variables.usersDict[message.Chat.Id].stopGameForReplicsQuestion)
                    {
                        if (message.Text == "Нет" || message.Text == "Нет")
                        {
                            await botClient.SendTextMessageAsync(message.Chat.Id, "Хорошо, тогда продолжаем игру. Кто это сказал?\n\n" + Variables.gameQuestions[Variables.usersDict[message.Chat.Id].gameLevel - 1], replyMarkup: Variables.GameAndReplicsKeyboard);
                            Variables.usersDict[message.Chat.Id].stopGameForReplicsQuestion = false;
                        }
                        else if ((Variables.usersDict[message.Chat.Id].stopGameForReplicsQuestion && message.Text == "Да" || message.Text == "Да"))
                        {
                            await botClient.SendTextMessageAsync(message.Chat.Id, "Игра остановлена");
                            Variables.usersDict[message.Chat.Id].stopGameForReplicsQuestion = false;
                        }
                        else
                        {
                            await botClient.SendTextMessageAsync(message.Chat.Id, "Не понимаю. Остановить игру ради реплик?");
                        }
                        return;

                    }



                    if (Variables.usersDict[message.Chat.Id].continueGameQuestion)
                    {
                        if (message.Text == "Нет" || message.Text == "нет")
                        {
                            await botClient.SendTextMessageAsync(message.Chat.Id, "Игра остановлена");
                            Variables.usersDict[message.Chat.Id].gameLevel = 0;
                            Variables.usersDict[message.Chat.Id].continueGameQuestion = false;
                        }
                        else if (message.Text == "Да" || message.Text == "да")
                        {
                            await botClient.SendTextMessageAsync(message.Chat.Id, "Хорошо, тогда продолжаем игру. Кто это сказал?\n\n" + Variables.gameQuestions[Variables.usersDict[message.Chat.Id].gameLevel - 1], replyMarkup: Variables.GameAndReplicsKeyboard);
                            Variables.usersDict[message.Chat.Id].continueGameQuestion = false;
                        }
                        else
                        {
                            await botClient.SendTextMessageAsync(message.Chat.Id, "Не понимаю. Продолжить игру?");
                        }

                        return;

                    }

                    if (Variables.usersDict[message.Chat.Id].continueReplicsQuestion)
                    {
                        if (message.Text == "Нет" || message.Text == "нет")
                        {
                            await botClient.SendTextMessageAsync(message.Chat.Id, "Реплики остановлены");
                            Variables.usersDict[message.Chat.Id].phraseRequest = false;
                            Variables.usersDict[message.Chat.Id].continueReplicsQuestion = false;
                        }
                        else if (message.Text == "Да" || message.Text == "да")
                        {
                            await botClient.SendTextMessageAsync(message.Chat.Id, "Хорошо. Вводите имя персонажа", replyMarkup: Variables.GameAndReplicsKeyboard);
                            Variables.usersDict[message.Chat.Id].continueReplicsQuestion = false;
                        }
                        else
                        {
                            await botClient.SendTextMessageAsync(message.Chat.Id, "Не понимаю. Продолжить реплики?");
                        }

                        return;

                    }




                    if (Variables.usersDict[message.Chat.Id].restartGameQuestion)
                    {
                        if (message.Text == "Да" || message.Text == "да")
                        {
                            Variables.usersDict[message.Chat.Id].gameLevel = 1;
                            await botClient.SendTextMessageAsync(message.Chat.Id, "Игра перезапущена. Кто это сказал?\n\n" + Variables.gameQuestions[Variables.usersDict[message.Chat.Id].gameLevel - 1], replyMarkup: Variables.GameAndReplicsKeyboard);
                            Variables.usersDict[message.Chat.Id].restartGameQuestion = false;
                        }
                        else if (message.Text == "Нет" || message.Text == "нет")
                        {
                            await botClient.SendTextMessageAsync(message.Chat.Id, "Хорошо, тогда продолжаем игру. Кто это сказал?\n\n" + Variables.gameQuestions[Variables.usersDict[message.Chat.Id].gameLevel - 1], replyMarkup: Variables.GameAndReplicsKeyboard);
                            Variables.usersDict[message.Chat.Id].restartGameQuestion = false;
                        }
                        else
                        {
                            await botClient.SendTextMessageAsync(message.Chat.Id, "Не понимаю.\n\n");
                        }

                        return;

                    }


                    if (message.Text == "Стоп" || message.Text == "стоп" || message.Text == "/command5")
                    {
                        await botClient.SendTextMessageAsync(message.Chat.Id, "Ну ладно.", replyMarkup: Variables.DefaultKeyboard);
                        Variables.usersDict[message.Chat.Id].phraseRequest = false;
                        Variables.usersDict[message.Chat.Id].heroPhrase = null;
                        Variables.usersDict[message.Chat.Id].gameLevel = 0;
                        Variables.usersDict[message.Chat.Id].trueAnswers = 0;
                        return;
                    }



                    if (Variables.usersDict[message.Chat.Id].phraseRequest)
                    {
                        Variables.usersDict[message.Chat.Id].heroName = message.Text;

                        switch (Variables.usersDict[message.Chat.Id].heroName)
                        {
                            case "Морт":
                                Variables.usersDict[message.Chat.Id].heroPhrase = "Без риска нет победы.";
                                break;
                            case "Граф Морт":
                                Variables.usersDict[message.Chat.Id].heroPhrase = "Без риска нет победы.";
                                break;
                            case "Болотный доктор":
                                Variables.usersDict[message.Chat.Id].heroPhrase = "Я вижу вы огорчены отрядами Плети около вашего графства?";
                                break;
                            case "Руфус":
                                Variables.usersDict[message.Chat.Id].heroPhrase = "Я вижу вы огорчены отрядами Плети около вашего графства?";
                                break;
                            case "Великус":
                                Variables.usersDict[message.Chat.Id].heroPhrase = "Точнее будет... Великус Многоликий.";
                                break;
                            case "Великус Многоликий":
                                Variables.usersDict[message.Chat.Id].heroPhrase = "Ты слишком много знаешь, Гориус!";
                                break;
                            case "Советник Гориус":
                                Variables.usersDict[message.Chat.Id].heroPhrase = "Не нравится мне это место. И старик сразу не понравился.";
                                break;
                            case "Гориус":
                                Variables.usersDict[message.Chat.Id].heroPhrase = "Не нравится мне это место. И старик сразу не понравился.";
                                break;
                            case "Говард Альтеренас":
                                Variables.usersDict[message.Chat.Id].heroPhrase = "ТЫ! ТЫ НЕ УЙДЁШЬ ОТ МЕНЯ, ПРЕДАТЕЛЬ!";
                                break;
                            case "Хаз'Гуул":
                                Variables.usersDict[message.Chat.Id].heroPhrase = "А, Руфус? Не забудь отдать ему графство";
                                break;
                            case "Хаз'Гуул Собиратель черепов":
                                Variables.usersDict[message.Chat.Id].heroPhrase = "Теперь я наконец исполню своё предназначение!";
                                break;
                            case "Хаз'Гуул собиратель черепов":
                                Variables.usersDict[message.Chat.Id].heroPhrase = "Теперь я наконец исполню своё предназначение!";
                                break;
                            case "Игра":
                                if (Variables.usersDict[message.Chat.Id].phraseRequest && !Variables.usersDict[message.Chat.Id].stopReplicsForGameQuestion)
                                {
                                    await botClient.SendTextMessageAsync(message.Chat.Id, "Вы хотите закончить реплики ради игры?", replyMarkup: Variables.YesOrNoKeyboard);
                                    Variables.usersDict[message.Chat.Id].phraseRequest = false;
                                    Variables.usersDict[message.Chat.Id].stopReplicsForGameQuestion = true;
                                    return;
                                }
                                break;

                            default:
                                Variables.usersDict[message.Chat.Id].heroPhrase = "Такого персонажа тупа не существует (в рамках впоисков силы)";
                                await botClient.SendTextMessageAsync(message.Chat.Id, "Выберите персонажа из списка", replyMarkup: Variables.GameAndReplicsKeyboard);
                                break;

                        }



                        await botClient.SendTextMessageAsync(message.Chat.Id, Variables.usersDict[message.Chat.Id].heroPhrase);
                        return;
                    }

                    if (Variables.usersDict[message.Chat.Id].stopGameForReplicsQuestion && (message.Text != "Нет" && message.Text != "нет" && message.Text != "да" && message.Text != "Да"))
                    {
                        await botClient.SendTextMessageAsync(message.Chat.Id, "Не понимаю.");
                    }




                    if (Variables.usersDict[message.Chat.Id].gameLevel > 0)
                    {

                        if (message.Text == "Игра" || message.Text == "игра")
                        {
                            await botClient.SendTextMessageAsync(message.Chat.Id, "Хотите начать игру заново?", replyMarkup: Variables.YesOrNoKeyboard);
                            Variables.usersDict[message.Chat.Id].restartGameQuestion = true;
                            return;
                        }

                        if (message.Text == Variables.gameCorrectVariants[Variables.usersDict[message.Chat.Id].gameLevel - 1])
                        {
                            await botClient.SendTextMessageAsync(message.Chat.Id, Variables.gameCorrectAnswers[Variables.usersDict[message.Chat.Id].gameLevel - 1]);
                            Variables.usersDict[message.Chat.Id].trueAnswers++;
                        }
                        else
                            await botClient.SendTextMessageAsync(message.Chat.Id, Variables.gameWrongAnswers[Variables.usersDict[message.Chat.Id].gameLevel - 1]);
                        Variables.usersDict[message.Chat.Id].gameLevel++;
                        if (Variables.usersDict[message.Chat.Id].gameLevel != 11)
                            await botClient.SendTextMessageAsync(message.Chat.Id, Variables.gameQuestions[Variables.usersDict[message.Chat.Id].gameLevel - 1]);

                        if (Variables.usersDict[message.Chat.Id].gameLevel == 11)
                        {
                            await botClient.SendTextMessageAsync(message.Chat.Id, "Вот и всё. Вопросы кончились. Давай подсчитаем верные ответы...");

                            if (Variables.usersDict[message.Chat.Id].trueAnswers == 0)
                                await botClient.SendTextMessageAsync(message.Chat.Id, "Очень плохо. Как можно было ни разу не угадать даже? Или ты специально?", replyMarkup: Variables.DefaultKeyboard);
                            if (1 <= Variables.usersDict[message.Chat.Id].trueAnswers && Variables.usersDict[message.Chat.Id].trueAnswers <= 3)
                                await botClient.SendTextMessageAsync(message.Chat.Id, "Правильных ответов: " + Variables.usersDict[message.Chat.Id].trueAnswers + "\n Думаю, тебе не помешает пересмотреть или перепройти кампанию", replyMarkup: Variables.DefaultKeyboard);
                            if (4 <= Variables.usersDict[message.Chat.Id].trueAnswers && Variables.usersDict[message.Chat.Id].trueAnswers <= 6)
                                await botClient.SendTextMessageAsync(message.Chat.Id, "Правильных ответов: " + Variables.usersDict[message.Chat.Id].trueAnswers + "\n У тебя есть определённые знания по 'Поискам силы'. Можно смело назвать тебя любителем этой кампании", replyMarkup: Variables.DefaultKeyboard);
                            if (7 <= Variables.usersDict[message.Chat.Id].trueAnswers && Variables.usersDict[message.Chat.Id].trueAnswers <= 9)
                                await botClient.SendTextMessageAsync(message.Chat.Id, "Правильных ответов: " + Variables.usersDict[message.Chat.Id].trueAnswers + "\n Ты действительно хорошо помнишь персонажей и их фразы. Молодца!", replyMarkup: Variables.DefaultKeyboard);
                            if (Variables.usersDict[message.Chat.Id].trueAnswers == 10)
                                await botClient.SendTextMessageAsync(message.Chat.Id, "Ты отлично знаешь кампанию! Так держать! Error Entertainment гордится тобой.", replyMarkup: Variables.DefaultKeyboard);


                            Variables.usersDict[message.Chat.Id].gameLevel = 0;
                        }
                        return;
                    }


                    if (Variables.usersDict[message.Chat.Id].stopReplicsForGameQuestion)
                    {
                        if (message.Text == "Да" || message.Text == "да")
                        {
                            await botClient.SendTextMessageAsync(message.Chat.Id, "Реплики остановлены");
                            Variables.usersDict[message.Chat.Id].phraseRequest = false;
                            Variables.usersDict[message.Chat.Id].stopReplicsForGameQuestion = false;
                            await botClient.SendTextMessageAsync(message.Chat.Id, "Давай проверим, насколько хорошо ты знаешь 'В поисках Силы'. Сможешь понять, кто произнёс следующие 10 фраз? Начнём:\n\n Так значит, этот рычаг откроет дверь к твоей свободе, трус?", replyMarkup: Variables.GameAndReplicsKeyboard);

                            Variables.usersDict[message.Chat.Id].gameLevel = 1;
                            Variables.usersDict[message.Chat.Id].trueAnswers = 0;
                            return;
                        }
                        else if (message.Text == "Нет" || message.Text == "нет")
                        {
                            await botClient.SendTextMessageAsync(message.Chat.Id, "Хорошо. Вводите имя персонажа", replyMarkup: Variables.GameAndReplicsKeyboard);
                            Variables.usersDict[message.Chat.Id].phraseRequest = true;
                            Variables.usersDict[message.Chat.Id].stopReplicsForGameQuestion = false;
                        }
                        else
                        {
                            await botClient.SendTextMessageAsync(message.Chat.Id, "Не понимаю. Остановить реплики?", replyMarkup: Variables.DefaultKeyboard);
                        }

                        return;

                    }

                    if (message.Text == "Игра" || message.Text == "/command4")
                    {


                        await botClient.SendTextMessageAsync(message.Chat.Id, "Давай проверим, насколько хорошо ты знаешь 'В поисках Силы'. Сможешь понять, кто произнёс следующие 10 фраз? Начнём:\n\n Так значит, этот рычаг откроет дверь к твоей свободе, трус?", replyMarkup: Variables.GameAndReplicsKeyboard);

                        Variables.usersDict[message.Chat.Id].gameLevel = 1;
                        Variables.usersDict[message.Chat.Id].trueAnswers = 0;
                        return;

                    }
                }

            }
            return;

        }


        private static Task Error(ITelegramBotClient arg1, Exception arg2, CancellationToken arg3)
        {
            throw new NotImplementedException();
        }
    }
}
